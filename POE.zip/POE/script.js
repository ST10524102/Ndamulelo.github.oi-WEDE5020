alert("Welcome to sparkleshine carwash");
document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("bookingForm");
    const message = document.getElementById("bookingMessage");
    if (!form || !message) {
        console.log("Booking form or message area not found.");
        return;
    }
    form.addEventListener("submit", function (event) {
        event.preventDefault();
        const name = document.getElementById("firstName").value;
        message.textContent =
            "Thank you, " + name +
            "! Your booking request has been submitted successfully.";
        message.style.color = "green";
        message.style.fontWeight = "bold";
        form.reset();
    });
});

document.addEventListener("DOMContentLoaded", function () {



    const bookingForm = document.getElementById("bookingForm");
    const bookingMessage = document.getElementById("bookingMessage");

    if (bookingForm && bookingMessage) {

        bookingForm.addEventListener("submit", function (event) {

            event.preventDefault();

            const name = document.getElementById("firstName").value;

            bookingMessage.textContent =
                "Thank you, " + name +
                "! Your booking request has been submitted successfully.";

            bookingMessage.style.color = "green";
            bookingMessage.style.fontWeight = "bold";

            bookingForm.reset();

        });

    }



    const contactForm = document.getElementById("contactForm");
    const contactStatus = document.getElementById("contactStatus");

    if (contactForm && contactStatus) {

        contactForm.addEventListener("submit", function (event) {

            event.preventDefault();

            const name = document.getElementById("contactName").value.trim();

            contactStatus.textContent =
                "Thank you, " + name +
                "! Your message has been submitted successfully. We appreciate you contacting SparkleShine Car Wash.";

            contactStatus.style.color = "green";
            contactStatus.style.fontWeight = "bold";

            contactForm.reset();

        });

    }

});


function addReview() {

    const reviewInput = document.getElementById("review");
    const reviewsList = document.getElementById("reviews");
    const reviewMessage = document.getElementById("reviewMessage");

    const reviewText = reviewInput.value.trim();

    if (reviewText === "") {

        reviewMessage.textContent = "Please write a review before submitting.";
        reviewMessage.style.color = "red";

        return;
    }

    const newReview = document.createElement("li");

    newReview.textContent = reviewText;

    reviewsList.appendChild(newReview);

    reviewMessage.textContent = "Thank you! Your review has been submitted.";
    reviewMessage.style.color = "green";

    reviewInput.value = "";

}

document.addEventListener("DOMContentLoaded", function () {
    const bookNowButton = document.getElementById("bookNowButton");
    const homeMessage = document.getElementById("homeMessage");
    if (bookNowButton && homeMessage) {
        bookNowButton.addEventListener("click", function () {
            homeMessage.textContent =
                "Great choice! Taking you to our booking page...";
            homeMessage.style.color = "green";
            homeMessage.style.fontWeight = "bold";
            setTimeout(function () {
                window.location.href = "Bookings.html";
            }, 1500);
        });
    }
});


document.addEventListener("DOMContentLoaded", function () {

    const promotionButtons = document.querySelectorAll(".promotion .button");

    promotionButtons.forEach(function (button) {

        button.addEventListener("click", function () {

            const promotion = button.closest(".promotion");
            const promotionName = promotion.querySelector("h2").textContent;

            sessionStorage.setItem("selectedPromotion", promotionName);

        });

    });

});
